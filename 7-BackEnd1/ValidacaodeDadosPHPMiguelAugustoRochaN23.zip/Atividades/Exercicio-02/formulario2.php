<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercício 2</title>
</head>
<body>
    <form action="valida2.php" method="POST">
        <label for="idade">Idade: </label>
        <input type="number" id="idade" name="idade"><br><br>

        <input type="submit" value="Enviar">
    </form>
</body>
</html>