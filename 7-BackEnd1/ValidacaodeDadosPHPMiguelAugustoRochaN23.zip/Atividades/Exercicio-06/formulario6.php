<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercício 6</title>
</head>
<body>
    <form action="valida6.php" method="post">
        <label for="produto">Produto:</label>
        <input type="text" id="produto" name="produto"><br><br>

        <label for="preco">Preço:</label>
        <input type="number" id="preco" name="preco"><br><br>

        <label for="desconto">Desconto(%):</label>
        <input type="number" id="desconto" name="desconto"><br><br>

        <input type="submit" value="Enviar">
    </form>
</body>
</html>
