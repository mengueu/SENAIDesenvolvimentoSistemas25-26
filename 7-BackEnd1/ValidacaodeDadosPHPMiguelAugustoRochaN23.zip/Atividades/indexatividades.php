<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atividades</title>
</head>
<body>
<?php
        echo "<h1> ATIVIDADES </h1>";
        echo "<h4><a href='Exercicio-01/formulario1.php'> Exercício 01 </a></h4>";
        echo "<h4><a href='Exercicio-02/formulario2.php'> Exercício 02 </a></h4>";
        echo "<h4><a href='Exercicio-03/formulario3.php'> Exercício 03 </a></h4>";
        echo "<h4><a href='Exercicio-04/formulario4.php'> Exercício 04 </a></h4>";
        echo "<h4><a href='Exercicio-05/formulario5.php'> Exercício 05 </a></h4>";
        echo "<h4><a href='Exercicio-06/formulario6.php'> Exercício 06 </a></h4>";
    ?>
</body>
</html>