<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercício 4</title>
</head>
<body>
    <form action="valida4.php" method="post">
        <label for="telefone">Telefone:</label>
        <input type="text" id="telefone" name="telefone"><br><br>
       

        <button type="submit">Enviar</button>
    </form>
</body>
</html>
